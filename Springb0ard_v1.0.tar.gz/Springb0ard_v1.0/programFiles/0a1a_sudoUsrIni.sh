#!/bin/bash
<<comment
* TITLE:  0a1a_sudoUsrIni.sh
* AUTHOR: Lance Pierson
* EMAIL:  info@treyark.com
* DATE:   2/5/23
* EXECUTIVE SUMMARY: Master Controller
comment
